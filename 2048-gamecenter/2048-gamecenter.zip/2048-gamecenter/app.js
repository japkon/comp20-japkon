var express = require('express');
var http = require('http');

var mongo = require('mongodb');

var app = express();

app.use(express.json());
app.use(express.urlencoded());
app.use(express.static(__dirname));


// Initialize Mongo
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL ||
	'mongodb://localhost/local';

app.get('/', function(request, response){
	mongo.Db.connect(mongoUri, function(err, db){
		db.collection("scores", function(err, collection){
			collection.find().sort({score : -1}).toArray(function(err, array){
				response_text = '<!DOCTYPE html><head><meta charset="UTF-8"><title>2048 Scoreboard</title>';
				response_text += '<link rel="stylesheet" href="app.css"/></head><body><h1>2048 Scores</h1>';
				response_text += '<table id="scores"><thead><tr><th>Username</th><th>Score</th><th>TimeStamp</th></tr></thead><tbody>';
				for(var i = 0; i < array.length; i++){
					response_text += '<tr><td>' + array[i]["username"] + '</td><td>' + array[i]["score"] + '</td><td>';
					response_text += array[i]["created_at"] + '</td></tr>';
				}
				response_text += '</tbody></body></html>';
				response.set('Content-Type', 'text/html');
				response.send(response_text);
			});
		});
	});
});

app.get('/scores.json', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	mongo.Db.connect(mongoUri, function(err, db){
		db.collection("scores", function(err, collection){
			var username = request.query.username;
			if (username != undefined){
				collection.find({"username":username}).sort({score : -1}).toArray(function(err, array){
					response.send(array);
				});
			} else {
				response.send('[]');
			}
		});
	});
});

app.post('/submit.json', function(request, response){
	response.header("Access-Control-Allow-Origin", "*");
	response.header("Access-Control-Allow-Headers", "X-Requested-With");
	mongo.Db.connect(mongoUri, function(err, db){
		db.collection("scores", function(err, collection){
			var username = request.body.username;
			var score = request.body.score;
			var grid = request.body.grid;
			if( username != undefined && score != undefined && grid != undefined){
				var time = new Date();
				collection.insert({"username":username, "score":score, "grid":grid, "created_at":time}, 
					function(err, array){});
				response.send("Received Data\n");
			} else {
				response.send("Bad Data\n");
			}
		});
	});
});

var port = Number(process.env.PORT || 3000);
app.listen(port, function(){
	console.log("listening on " + port);
});